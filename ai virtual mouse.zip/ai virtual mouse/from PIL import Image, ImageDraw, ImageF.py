from PIL import Image, ImageDraw, ImageFont
import os

# Create a new image with a white background
width, height = 800, 600
image = Image.new('RGB', (width, height), color='white')

# Create a drawing object
draw = ImageDraw.Draw(image)

# Draw a large question mark
font_large = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 150)
draw.text((width//2, height//2-50), "?", fill='black', font=font_large, anchor="mm")

# Draw thought bubbles
bubble_centers = [(200, 150), (600, 150), (200, 450), (600, 450)]
bubble_sizes = [100, 80, 90, 70]
bubble_contents = ["\ud83d\udcca", "\ud83d\udcf7", "\ud83d\udcdd", "\ud83e\udde0"]

font_small = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 40)

for center, size, content in zip(bubble_centers, bubble_sizes, bubble_contents):
    x, y = center
    draw.ellipse([x-size//2, y-size//2, x+size//2, y+size//2], outline='black', width=2)
    draw.text((x, y), content, fill='black', font=font_small, anchor="mm")

# Add text at the bottom
font_bottom = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 24)
draw.text((width//2, height-30), "Visuals vs. Text in Learning", fill='black', font=font_bottom, anchor="mm")

# Save the image
filename = "visuals_enhance_learning.png"
image.save(filename)
print(f"Image saved as {filename}")

# Display the image
from IPython.display import display, Image as IPImage
display(IPImage(filename))